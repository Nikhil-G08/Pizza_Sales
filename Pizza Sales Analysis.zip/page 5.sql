-- Identify the most common pizza size ordered.

SELECT 
    COUNT(od.order_id) AS MOST_ORDERED, p.size
FROM
    pizzas p
        INNER JOIN
    order_details od ON p.pizza_id = od.pizza_id
GROUP BY p.size
ORDER BY MOST_ORDERED DESC;

