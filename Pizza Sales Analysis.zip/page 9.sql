-- Group the orders by date and calculate the average number of pizzas ordered per day.

SELECT 
    ROUND(AVG(quantity),2) AS ORDERS_PER_DAY
FROM
    (SELECT 
        orders.Date, SUM(order_details.quantity) AS QUANTITY
    FROM
        orders
    JOIN order_details ON order_details.order_id = orders.order_id
    GROUP BY orders.Date) AS a;
    
