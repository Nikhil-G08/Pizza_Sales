-- List the top 5 most ordered pizza types along with their quantities.

SELECT 
    p.pizza_type_id AS pizza_type, SUM(od.quantity) AS Total_QTY
FROM
    pizzas p
        JOIN
    order_details od ON p.pizza_id = od.pizza_id
GROUP BY pizza_type
ORDER BY Total_QTY DESC
LIMIT 5;
