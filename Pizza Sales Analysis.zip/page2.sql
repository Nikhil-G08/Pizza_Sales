-- 	Retrieve the total number of orders placed

SELECT 
    COUNT(order_details_id) AS TOTAL_ORDERS_PLACED
FROM
    order_details;