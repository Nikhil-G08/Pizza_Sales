-- Join relevant tables to find the category-wise distribution of pizzas

SELECT 
    pizza_types.category, COUNT(name) AS DISTRIBUTION
FROM
    pizzas
        JOIN
    pizza_types ON pizzas.pizza_type_id = pizza_types.pizza_type_id
GROUP BY pizza_types.category;


#INCLUDNG S,M,L sizes

