-- Analyze the cumulative revenue generated over time.

SELECT orders.Date ,SUM(order_details.quantity*pizzas.price) OVER(ORDER BY orders.Date) AS CUM FROM 
(SELECT orders.Date ,sum(order_details.quantity*pizzas.price) AS TOTAL_REVENUE
FROM pizzas
JOIN order_details
ON pizzas.pizza_id=order_details.pizza_id
JOIN orders
ON orders.order_id=order_details.order_id
GROUP BY orders.Date) AS SALES;