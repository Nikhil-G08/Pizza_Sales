-- Determine the distribution of orders by hour of the day.

SELECT 
    HOUR(orders.time) AS HOUR, COUNT(orders.order_id) COUNT_BY_TIME
FROM
    orders
GROUP BY HOUR(orders.time);