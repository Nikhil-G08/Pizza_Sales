 -- Calculate the total revenue generated from pizza sales.
 
 SELECT 
    CEIL(SUM(p.price * od.quantity)) AS TOTAL_SALES
FROM
    pizzas p
        CROSS JOIN
    order_details od ON p.pizza_id = od.pizza_id;
 
  