-- Identify the highest-priced pizza for each size


SELECT 
    size AS SIZE, MAX(price) AS MAX_PRICE
FROM
    pizzas
GROUP BY size
ORDER BY MAX_PRICE DESC;







